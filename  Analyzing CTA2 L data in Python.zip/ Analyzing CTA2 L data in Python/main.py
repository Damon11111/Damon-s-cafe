#
# header comment? Overview, name, etc.
#

import sqlite3
import matplotlib.pyplot as plt

##################################################################
#
# print_stats
#
# Given a connection to the CTA database, executes various
# SQL queries to retrieve and output basic stats.
#


def date_times(dbConn):
    query = "select strftime('%Y-%m-%d',Ride_date),sum(Num_Riders) from Ridership group by strftime('%Y-%m-%d',Ride_date) order by strftime('%Y-%m-%d',Ride_date);"

    dbCursor = dbConn.cursor()

    dbCursor.execute(query)

    result = dbCursor.fetchall()

    year = [i[0] for i in result]
    max_date = max(year)
    min_date = min(year)
    print("  date range:", min_date, "-", max_date)


def print_stats(dbConn):
    dbCursor = dbConn.cursor()
    print(" ")
    print("General stats:")

    dbCursor.execute("Select count(*) From Stations;")
    row = dbCursor.fetchone()
    print("  # of stations:", f"{row[0]:,}")

    dbCursor.execute("Select count(*) From Stops;")
    row1 = dbCursor.fetchone()
    print("  # of stops:", f"{row1[0]:,}")

    dbCursor.execute("Select count(*) From Ridership;")
    row2 = dbCursor.fetchone()
    print("  # of ride entries:", f"{row2[0]:,}")

    date_times(dbConn)

    dbCursor.execute("Select sum(Num_Riders) From Ridership;")
    row3 = dbCursor.fetchone()
    print("  Total ridership:", f"{row3[0]:,}")

    dbCursor.execute(
        "Select sum(Num_Riders) From Ridership where Type_of_Day = 'W';")
    row4 = dbCursor.fetchone()
    print(
        "  Weekday ridership:", f"{row4[0]:,}" + " (" +
        "{:.2f}".format(row4[0] / row3[0] * 100) + "%)")

    dbCursor.execute(
        "Select sum(Num_Riders) From Ridership where Type_of_Day = 'A';")
    row5 = dbCursor.fetchone()
    print(
        "  Saturday ridership:", f"{row5[0]:,}" + " (" +
        "{:.2f}".format(row5[0] / row3[0] * 100) + "%)")

    dbCursor.execute(
        "Select sum(Num_Riders) From Ridership where Type_of_Day = 'U';")
    row6 = dbCursor.fetchone()
    print(
        "  Sunday/holiday ridership:", f"{row6[0]:,}" + " (" +
        "{:.2f}".format(row6[0] / row3[0] * 100) + "%)")


def command_1(dbConn):

    command1 = input("\nEnter partial station name (wildcards _ and %): ")

    query = "select Station_ID, Station_Name from Stations where Station_Name like ? group by Station_ID, Station_Name order by Station_Name"

    dbCursor = dbConn.cursor()

    dbCursor.execute(query, [command1])

    result = dbCursor.fetchall()

    if len(result) == 0:
        print("**No stations found...")

    for row in result:
        print(row[0], ":", row[1])


def command_2(dbConn):

    query = "select Station_Name, sum(Num_Riders),sum(sum(Num_Riders)) over() from Stations as s inner join Ridership as r on s.Station_ID = r.Station_ID group by Station_Name order by Station_Name "

    dbCursor = dbConn.cursor()

    dbCursor.execute(query)

    result = dbCursor.fetchall()
    print("** ridership all stations **")
    for row in result:

        print(row[0] + " : " + f"{row[1]:,d}" + " (" +
              "{:.2f}".format(row[1] / row[2] * 100) + "%)")


def command_3(dbConn):
    query = "select Station_Name, sum(Num_Riders),sum(sum(Num_Riders)) over() from Stations as s inner join Ridership as r on s.Station_ID = r.Station_ID group by Station_Name order by sum(Num_Riders) desc limit 10 "

    dbCursor = dbConn.cursor()

    dbCursor.execute(query)

    result = dbCursor.fetchall()
    print("** top-10 stations **")
    for row in result:
        print(row[0] + " : " + f"{row[1]:,d}" + " (" +
              "{:.2f}".format(row[1] / row[2] * 100) + "%)")


def command_4(dbConn):
    query = "select Station_Name, sum(Num_Riders),sum(sum(Num_Riders)) over() from Stations as s inner join Ridership as r on s.Station_ID = r.Station_ID group by Station_Name order by sum(Num_Riders) limit 10 "

    dbCursor = dbConn.cursor()

    dbCursor.execute(query)

    result = dbCursor.fetchall()
    print("** least-10 stations **")
    for row in result:
        print(row[0] + " : " + f"{row[1]:,d}" + " (" +
              "{:.2f}".format(row[1] / row[2] * 100) + "%)")


def command_5(dbConn):
    command5 = input("\nEnter a line color (e.g. Red or Yellow): ")

    query = "select Stop_Name,Direction, ADA from Lines as l inner join StopDetails as sd on l.Color like ? and l.Line_ID = sd.Line_ID inner join Stops as s on sd.Stop_ID = s.Stop_ID group by Stop_Name,s.Stop_ID order by Stop_Name"

    dbCursor = dbConn.cursor()

    dbCursor.execute(query, [command5])

    result = dbCursor.fetchall()

    if len(result) != 0:

        for row in result:

            if row[2] == 1:
                print(row[0], " : direction = ", row[1], " (accessible? yes)")
            else:
                print(row[0], " : direction = ", row[1], " (accessible? no)")

    else:
        print("**No such line...")


def command_6(dbConn):
    query = "select strftime('%m',Ride_date),sum(Num_Riders) from Ridership  group by strftime('%m',Ride_date) order by strftime('%m',Ride_date);"

    dbCursor = dbConn.cursor()

    dbCursor.execute(query)

    result = dbCursor.fetchall()
    print("** ridership by month **")

    for row in result:
        print(row[0], ":", f"{row[1]:,d}")

    data = input("\nPlot? (y/n) ")
    x = []
    y = []

    if data == "y":
        for row in result:
            x.append(row[0])
            y.append(row[1])

        plt.xlabel("Month")
        plt.ylabel("number of riders (x * 10^8)")
        plt.title("monthly ridership")
        plt.plot(x, y)
        plt.show()

    elif data == "n":
        return

    else:
        print("**Error, unknown command...")


def command_7(dbConn):
    query = "select strftime('%Y',Ride_date),sum(Num_Riders) from Ridership group by strftime('%Y',Ride_date) order by strftime('%Y',Ride_date);"

    dbCursor = dbConn.cursor()

    dbCursor.execute(query)

    result = dbCursor.fetchall()
    print("** ridership by year **")

    for row in result:
        print(row[0], ":", f"{row[1]:,d}")

    data = input("\nPlot? (y/n) ")
    x = []
    y = []

    if data == "y":
        for row in result:
            x.append(str(row[0][-2:]))
            y.append(row[1])

        plt.xlabel("Year")
        plt.ylabel("number of riders (x * 10^8)")
        plt.title("yearly ridership")
        plt.plot(x, y)
        plt.show()

    elif data == "n":
        return

    else:
        print("**Error, unknown command...")


def command_8(dbConn):
    data1 = input("\nYear to compare against? ")
    if len(data1) < 4:
        print("**Please entry Year to compare against...")

    data2 = input("\nEnter station 1 (wildcards _ and %): ")
    query = "select strftime('%Y-%m-%d',Ride_date),Num_Riders,s.Station_Name from Ridership as r inner join Stations as s on  strftime('%Y',Ride_date) = ? and r.Station_ID = s.Station_ID and s.Station_Name like ?group by strftime('%Y %m %d',Ride_date),r.Station_ID,s.Station_Name order by strftime('%Y %m %d',Ride_date) limit 5 ;"

    query3 = "select s.Station_ID,s.Station_Name from Ridership as r inner join Stations as s on  strftime('%Y',Ride_date) = ? and r.Station_ID = s.Station_ID and s.Station_Name like ? group by strftime('%Y',Ride_date),r.Station_ID;"

    query5 = "select strftime('%Y-%m-%d',Ride_date),Num_Riders,s.Station_Name from Ridership as r inner join Stations as s on  strftime('%Y',Ride_date) = ? and r.Station_ID = s.Station_ID and s.Station_Name like ? group by strftime('%Y %m %d',Ride_date),r.Station_ID,s.Station_Name order by strftime('%Y %m %d',Ride_date) desc limit 5"

    query7 = "select strftime('%Y %m %d',Ride_date),Num_Riders,s.Station_Name from Ridership as r inner join Stations as s on  strftime('%Y',Ride_date) = ? and r.Station_ID = s.Station_ID and s.Station_Name like ?group by strftime('%Y %m %d',Ride_date),r.Station_ID,s.Station_Name order by strftime('%Y %m %d',Ride_date) ;"

    dbCursor = dbConn.cursor()

    dbCursor.execute(query, [data1, data2])
    result = dbCursor.fetchall()

    dbCursor.execute(query3, [data1, data2])
    result3 = dbCursor.fetchall()

    dbCursor.execute(query5, [data1, data2])
    result5 = dbCursor.fetchall()
    result5.reverse()

    dbCursor.execute(query7, [data1, data2])
    result7 = dbCursor.fetchall()

    if len(result3) > 1:
        print("**Multiple stations found...")
        return

    if len(result) == 0:
        print("**No station found...")
        return

    data3 = input("\nEnter station 2 (wildcards _ and %): ")

    query2 = "select strftime('%Y-%m-%d',Ride_date),Num_Riders,s.Station_Name from Ridership as r inner join Stations as s on  strftime('%Y',Ride_date) = ? and r.Station_ID = s.Station_ID and s.Station_Name like ?group by strftime('%Y %m %d',Ride_date),r.Station_ID,s.Station_Name order by strftime('%Y %m %d',Ride_date) limit 5 ;"

    query4 = "select s.Station_ID,s.Station_Name from Ridership as r inner join Stations as s on  strftime('%Y',Ride_date) = ? and r.Station_ID = s.Station_ID and s.Station_Name like ? group by strftime('%Y',Ride_date),r.Station_ID;"

    query6 = "select strftime('%Y-%m-%d',Ride_date),Num_Riders,s.Station_Name from Ridership as r inner join Stations as s on  strftime('%Y',Ride_date) = ? and r.Station_ID = s.Station_ID and s.Station_Name like ? group by strftime('%Y %m %d',Ride_date),r.Station_ID,s.Station_Name order by strftime('%Y %m %d',Ride_date) desc limit 5"

    query8 = "select strftime('%Y %m %d',Ride_date),Num_Riders,s.Station_Name from Ridership as r inner join Stations as s on  strftime('%Y',Ride_date) = ? and r.Station_ID = s.Station_ID and s.Station_Name like ?group by strftime('%Y %m %d',Ride_date),r.Station_ID,s.Station_Name order by strftime('%Y %m %d',Ride_date);"

    dbCursor.execute(query2, [data1, data3])
    result2 = dbCursor.fetchall()

    dbCursor.execute(query4, [data1, data3])
    result4 = dbCursor.fetchall()

    dbCursor.execute(query6, [data1, data3])
    result6 = dbCursor.fetchall()
    result6.reverse()

    dbCursor.execute(query8, [data1, data3])
    result8 = dbCursor.fetchall()

    if len(result4) > 1:
        print("**Multiple stations found...")
        return

    if len(result2) == 0:
        print("**No station found...")
        return

    for row2 in result3:
        print("Station 1: " + str(row2[0]) + " " + row2[1])
    for row in result:

        print(row[0], row[1])
    for row4 in result5:
        print(row4[0], row4[1])
    for row3 in result4:
        print("Station 2: " + str(row3[0]) + " " + row3[1])
    for row1 in result2:
        print(row1[0], row1[1])
    for row4 in result6:
        print(row4[0], row4[1])

    data = input("\nPlot? (y/n) ")
    x = []
    y = []

    j = []

    if data == "y":
        for row in result7:
            y.append(row[1])
        for row1 in result8:
            j.append(row1[1])

        x = list(range(0, len(y)))
        x1 = list(range(0, len(j)))
        plt.xlabel("day")
        plt.ylabel("number of riders")
        plt.title("riders each day of " + data1)
        plt.plot(x, y, color='blue', label=row2[1])
        plt.plot(x1, j, color='orange', label=row3[1])
        plt.legend()
        plt.show()

    elif data == "n":
        return

    else:
        print("**Error, unknown command...")


def command_9(dbConn):
    command9 = input("\nEnter a line color (e.g. Red or Yellow): ")

    query = "select Station_Name, Latitude, Longitude from Stations as s inner join Stops as st on s.Station_ID = st.Station_ID inner join StopDetails as sd on sd.Stop_ID = st.Stop_ID inner join Lines as l on l.Line_ID = sd.Line_ID and Color like ? group by Station_Name"

    dbCursor = dbConn.cursor()

    dbCursor.execute(query, [command9])

    result = dbCursor.fetchall()

    if len(result) != 0:
        for row in result:
            str_row1 = str(row[1])
            str_row2 = str(row[2])
            print(row[0], ": (" + str_row1 + ", " + str_row2 + ")")

    else:
        print("**No such line...")
        return

    data = input("\nPlot? (y/n) ")

    if data == "y":
        x = []
        y = []
        for row in result:
            x.append(row[2])
            y.append(row[1])

        image = plt.imread("chicago.png")
        xydims = [-87.9277, -87.5569, 41.7012, 42.0868]

        plt.imshow(image, extent=xydims)
        plt.title(command9 + " line")

        if (command9.lower() == "purple-express"):
            command9 = "Purple"

        plt.plot(x, y, "o", c=command9)
        # plt.plot(x,y)

        for row in result:
            plt.annotate(row[0], (row[2], row[1]))

        plt.ylim([41.7012, 42.0868])
        plt.xlim([-87.9277, -87.5569])

        plt.show()

    elif data == "n":
        return

    else:
        print("**Error, unknown command...")


##################################################################
#
# main
#
print('** Welcome to CTA L analysis app **')

dbConn = sqlite3.connect('CTA2_L_daily_ridership.db')

print_stats(dbConn)
data = input("\nPlease enter a command (1-9, x to exit): ")
while data != "x":

    if data == "1":
        command_1(dbConn)

    elif data == "2":
        command_2(dbConn)

    elif data == "3":
        command_3(dbConn)

    elif data == "4":
        command_4(dbConn)

    elif data == "5":
        command_5(dbConn)

    elif data == "6":
        command_6(dbConn)

    elif data == "7":
        command_7(dbConn)

    elif data == "8":
        command_8(dbConn)

    elif data == "9":
        command_9(dbConn)

    else:
        print("**Error, unknown command, try again...")

    data = input("\nPlease enter a command (1-9, x to exit): ")

#
# done
#
